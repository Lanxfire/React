import React from 'react';

function About() {
  return (
    <div>
      <h2>Acerca De Nosotros</h2>
      <p>Somos una empresa dedicada a...</p>
    </div>
  );
}

export default About;