import React from 'react';

function Home() {
  return (
    <div>
      <h2>Bienvenido a la Página de Inicio</h2>
      <p>Explora nuestros productos y conoce más sobre nosotros.</p>
    </div>
  );
}

export default Home;