import React from 'react';
function HomePage() {
  return (
    <div className="page-content">
      <h2>🏠 ¡Bienvenido a Casa!</h2>
      <p>Esta es la página principal de nuestra SPA.</p>
    </div>
  );
}
export default HomePage;